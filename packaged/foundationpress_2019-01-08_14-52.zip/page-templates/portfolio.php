<?php
/*
Template Name: Portfolio
*/
get_header(); ?>
<?php get_footer();